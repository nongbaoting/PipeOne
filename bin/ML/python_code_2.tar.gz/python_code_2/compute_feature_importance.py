from feature_selection_utils import *

data_dir = "./data/top200/"
tree_num = 30
max_depth = 4
min_samples_split = 7

X, y, feature_name = load_data(data_dir)


print()


